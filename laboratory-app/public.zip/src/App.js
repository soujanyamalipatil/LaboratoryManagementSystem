import { useState } from 'react';
import './App.css';
import AdminHomePage from './components/AdminHomePage';
import AdminLogin from './components/AdminLogin';
import HaemotologyReport from './components/HaemotologyReport';
import ProtectedRoute from './components/ProtectedRoute';
// import SelectTestPage from './components/SelectTestPage';
import RegisterPage from './components/RegisterPage'
import SampleDetails from './components/SampleDetails';
import SampleReportDetails from './components/SampleReportDetails';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom'
function App() {
  const [adminLogin, setadminLogin] = useState(false);
  const [error, seterror] = useState()
  const isLoginData=localStorage.getItem("isAuth");
 
  
  // const loginauth=localStorage.getItem('token')
  return (
    <Router>
      <div className="App">
       
    {/* <RegisterPage/> */}
     {/* <AdminHomePage setadminLogin={setadminLogin} /> */}
      
      {adminLogin||isLoginData?<AdminHomePage setadminLogin={setadminLogin} />:
      <Route path="/"><AdminLogin setadminLogin={setadminLogin} 
      seterror={seterror} error={error}/></Route>} 
     
{/* <HaemotologyReport/> */}
{/* <SampleDetails/> */}
{/* <SampleReportDetails/> */}
    </div>
    </Router>
  );
}

export default App;
