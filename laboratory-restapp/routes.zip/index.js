const port=4000
const app=require('./app')
app.listen(port,()=>{
    console.log(`the server listenning ${port}`)
})
